package com.example.addon;

import meteordevelopment.meteorclient.events.game.GameLeftEvent;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.widgets.WWidget;
import meteordevelopment.meteorclient.gui.widgets.pressable.WButton;
import meteordevelopment.meteorclient.pathing.PathManagers;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.player.SlotUtils;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.BlockState;
import net.minecraft.block.FluidBlock;
import net.minecraft.block.Block;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

import static meteordevelopment.meteorclient.MeteorClient.mc;

/**
 * Digs out a box between two corners, one layer at a time.
 * It re-scans the world instead of predicting what a 3x3 pickaxe breaks, so
 * it works with any hammer/3x3 tool: whatever the tool clears simply stops
 * showing up as "remaining" on the next scan.
 */
public class AutoMiner extends Module {
    public enum LayerOrder {
        TopDown,
        BottomUp
    }

    public enum TargetMode {
        Closest,
        Sweep
    }

    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgTargeting = settings.createGroup("Targeting");
    private final SettingGroup sgTool = settings.createGroup("Tool");
    private final SettingGroup sgSafety = settings.createGroup("Safety");
    private final SettingGroup sgMessages = settings.createGroup("Messages");
    private final SettingGroup sgRender = settings.createGroup("Render");

    // ---------------------------------------------------------------- General

    private final Setting<Double> range = sgGeneral.add(new DoubleSetting.Builder()
        .name("range")
        .description("How far away a block can be before the miner walks closer.")
        .defaultValue(4.5)
        .min(1)
        .sliderMax(6)
        .build());

    private final Setting<Integer> mineDelay = sgGeneral.add(new IntSetting.Builder()
        .name("mine-delay")
        .description("Ticks to wait between mining actions. 0 = every tick.")
        .defaultValue(0)
        .min(0)
        .sliderMax(20)
        .build());

    private final Setting<Boolean> rotate = sgGeneral.add(new BoolSetting.Builder()
        .name("rotate")
        .description("Look at the block being mined.")
        .defaultValue(true)
        .build());

    private final Setting<Boolean> smoothRotation = sgGeneral.add(new BoolSetting.Builder()
        .name("smooth-rotation")
        .description("Turn the camera gradually toward blocks instead of snapping to them.")
        .defaultValue(true)
        .visible(rotate::get)
        .build());

    private final Setting<Double> rotationSpeed = sgGeneral.add(new DoubleSetting.Builder()
        .name("rotation-speed")
        .description("Max degrees the camera turns per tick when smooth-rotation is on.")
        .defaultValue(18)
        .min(2)
        .sliderMax(60)
        .visible(() -> rotate.get() && smoothRotation.get())
        .build());

    private final Setting<Boolean> pathing = sgGeneral.add(new BoolSetting.Builder()
        .name("walk-to-blocks")
        .description("Use Meteor's pathing (Baritone) to walk to blocks that are out of range.")
        .defaultValue(true)
        .build());

    private final Setting<Boolean> autoDisable = sgGeneral.add(new BoolSetting.Builder()
        .name("auto-disable")
        .description("Turn off when the whole region has been cleared.")
        .defaultValue(true)
        .build());

    private final Setting<Boolean> disableOnLeave = sgGeneral.add(new BoolSetting.Builder()
        .name("disable-on-leave")
        .description("Turn off when you leave the world or server.")
        .defaultValue(true)
        .build());

    // -------------------------------------------------------------- Targeting

    private final Setting<LayerOrder> layerOrder = sgTargeting.add(new EnumSetting.Builder<LayerOrder>()
        .name("layer-order")
        .description("Which way the miner works through the layers.")
        .defaultValue(LayerOrder.TopDown)
        .build());

    private final Setting<TargetMode> targetMode = sgTargeting.add(new EnumSetting.Builder<TargetMode>()
        .name("target-mode")
        .description("Closest: always the nearest block. Sweep: tidy rows, back and forth.")
        .defaultValue(TargetMode.Closest)
        .build());

    private final Setting<List<Block>> ignoredBlocks = sgTargeting.add(new BlockListSetting.Builder()
        .name("ignored-blocks")
        .description("Blocks the miner will leave alone.")
        .build());

    private final Setting<Integer> rescanInterval = sgTargeting.add(new IntSetting.Builder()
        .name("rescan-interval")
        .description("Ticks between full scans of the current layer.")
        .defaultValue(5)
        .min(1)
        .sliderMax(20)
        .build());

    // ------------------------------------------------------------------- Tool

    private final Setting<Integer> hotbarSlot = sgTool.add(new IntSetting.Builder()
        .name("hotbar-slot")
        .description("Hotbar slot (1-9) holding your 3x3 pickaxe. 0 = use whatever you are holding.")
        .defaultValue(0)
        .min(0)
        .max(9)
        .sliderMax(9)
        .build());

    private final Setting<Boolean> stopOnLowDurability = sgTool.add(new BoolSetting.Builder()
        .name("stop-on-low-durability")
        .description("Stop before your tool breaks.")
        .defaultValue(true)
        .build());

    private final Setting<Integer> minDurability = sgTool.add(new IntSetting.Builder()
        .name("min-durability")
        .description("Stop when the tool has this much durability left.")
        .defaultValue(10)
        .min(1)
        .sliderMax(200)
        .visible(stopOnLowDurability::get)
        .build());

    // ----------------------------------------------------------------- Safety

    private final Setting<Double> pauseBelowHealth = sgSafety.add(new DoubleSetting.Builder()
        .name("pause-below-health")
        .description("Pause mining while your health is below this. 0 = never pause.")
        .defaultValue(6)
        .min(0)
        .sliderMax(20)
        .build());

    private final Setting<Boolean> stopWhenInventoryFull = sgSafety.add(new BoolSetting.Builder()
        .name("stop-when-inventory-full")
        .description("Turn off when you have no empty inventory slot left.")
        .defaultValue(false)
        .build());

    // --------------------------------------------------------------- Messages

    private final Setting<Boolean> progressMessages = sgMessages.add(new BoolSetting.Builder()
        .name("progress-messages")
        .description("Send a chat message at 25%, 50% and 75%.")
        .defaultValue(true)
        .build());

    // ----------------------------------------------------------------- Render

    private final Setting<Boolean> renderRegion = sgRender.add(new BoolSetting.Builder()
        .name("render-region")
        .description("Draw the selected region and corners.")
        .defaultValue(true)
        .build());

    private final Setting<Boolean> renderLayer = sgRender.add(new BoolSetting.Builder()
        .name("render-layer")
        .description("Highlight the layer being mined.")
        .defaultValue(true)
        .build());

    private final Setting<Boolean> renderTarget = sgRender.add(new BoolSetting.Builder()
        .name("render-target")
        .description("Highlight the block being mined.")
        .defaultValue(true)
        .build());

    private final Setting<ShapeMode> shapeMode = sgRender.add(new EnumSetting.Builder<ShapeMode>()
        .name("shape-mode")
        .defaultValue(ShapeMode.Both)
        .build());

    private final Setting<SettingColor> sideColor = sgRender.add(new ColorSetting.Builder()
        .name("region-side-color")
        .defaultValue(new SettingColor(255, 170, 0, 20))
        .build());

    private final Setting<SettingColor> lineColor = sgRender.add(new ColorSetting.Builder()
        .name("region-line-color")
        .defaultValue(new SettingColor(255, 170, 0, 255))
        .build());

    private final Setting<SettingColor> layerSideColor = sgRender.add(new ColorSetting.Builder()
        .name("layer-side-color")
        .defaultValue(new SettingColor(80, 200, 255, 25))
        .build());

    private final Setting<SettingColor> layerLineColor = sgRender.add(new ColorSetting.Builder()
        .name("layer-line-color")
        .defaultValue(new SettingColor(80, 200, 255, 200))
        .build());

    private final Setting<SettingColor> targetSideColor = sgRender.add(new ColorSetting.Builder()
        .name("target-side-color")
        .defaultValue(new SettingColor(255, 60, 60, 40))
        .build());

    private final Setting<SettingColor> targetLineColor = sgRender.add(new ColorSetting.Builder()
        .name("target-line-color")
        .defaultValue(new SettingColor(255, 60, 60, 255))
        .build());

    // ------------------------------------------------------------------ State

    /** Region corners (set with the panel, .miner pos1 / .miner pos2). */
    public BlockPos pos1, pos2;

    private int minX, minY, minZ, maxX, maxY, maxZ;
    private int layerY, layerStep;
    private int layerInitial, layersDone, totalLayers;
    private long doneBlocks;
    private int scanTimer, delayTimer;
    private long ticksRunning;
    private int lastQuarter;
    private BlockPos currentTarget;
    private String statusText = "Idle";
    private List<BlockPos> cache = new ArrayList<>();

    public AutoMiner() {
        super(AddonTemplate.CATEGORY, "auto-miner", "Digs out the box between two points with a 3x3 pickaxe.");
    }

    // --------------------------------------------------------------- Public API

    public boolean hasRegion() {
        return pos1 != null && pos2 != null;
    }

    public void setCorner(int which, BlockPos pos) {
        if (which == 1) pos1 = pos;
        else pos2 = pos;
        refreshPanel();
    }

    public void clearRegion() {
        if (isActive()) toggle();
        pos1 = null;
        pos2 = null;
        statusText = "Idle";
        refreshPanel();
    }

    public String getStatusText() {
        return statusText;
    }

    public long getRegionVolume() {
        if (!hasRegion()) return 0;
        long dx = Math.abs(pos1.getX() - pos2.getX()) + 1;
        long dy = Math.abs(pos1.getY() - pos2.getY()) + 1;
        long dz = Math.abs(pos1.getZ() - pos2.getZ()) + 1;
        return dx * dy * dz;
    }

    /** 0.0 to 1.0 */
    public double getProgress() {
        if (statusText.equals("Cleared")) return 1.0;
        if (!isActive() || totalLayers <= 0) return 0;
        double partial = layerInitial == 0 ? 0 : 1.0 - cache.size() / (double) layerInitial;
        return MathHelper.clamp((layersDone + partial) / totalLayers, 0.0, 1.0);
    }

    public long getBlocksCleared() {
        if (statusText.equals("Cleared")) return doneBlocks;
        if (!isActive()) return 0;
        return doneBlocks + Math.max(0, layerInitial - cache.size());
    }

    public long getElapsedSeconds() {
        return ticksRunning / 20;
    }

    /** Seconds left, or -1 if not enough data yet. */
    public long getEtaSeconds() {
        double p = getProgress();
        if (p < 0.01) return -1;
        return (long) (getElapsedSeconds() * (1.0 - p) / p);
    }

    private void refreshPanel() {
        if (MinerScreen.current != null) MinerScreen.current.update();
    }

    // ---------------------------------------------------------------- GUI hook

    @Override
    public WWidget getWidget(GuiTheme theme) {
        WButton open = theme.button("Open Miner Panel");
        open.action = () -> mc.setScreen(new MinerScreen(theme, this));
        return open;
    }

    // ------------------------------------------------------------ Save / load

    @Override
    public NbtCompound toTag() {
        NbtCompound tag = super.toTag();
        if (tag == null) return null;

        if (pos1 != null) {
            tag.putInt("p1x", pos1.getX());
            tag.putInt("p1y", pos1.getY());
            tag.putInt("p1z", pos1.getZ());
        }
        if (pos2 != null) {
            tag.putInt("p2x", pos2.getX());
            tag.putInt("p2y", pos2.getY());
            tag.putInt("p2z", pos2.getZ());
        }

        // Never start mining by itself when the game launches.
        tag.putBoolean("active", false);
        return tag;
    }

    @Override
    public Module fromTag(NbtCompound tag) {
        if (tag.contains("p1x")) {
            pos1 = new BlockPos(tag.getInt("p1x", 0), tag.getInt("p1y", 0), tag.getInt("p1z", 0));
        }
        if (tag.contains("p2x")) {
            pos2 = new BlockPos(tag.getInt("p2x", 0), tag.getInt("p2y", 0), tag.getInt("p2z", 0));
        }
        return super.fromTag(tag);
    }

    // -------------------------------------------------------------- Lifecycle

    @Override
    public void onActivate() {
        if (!hasRegion()) {
            error("Set both corners first (open the panel, or use .miner pos1 / .miner pos2).");
            toggle();
            return;
        }

        minX = Math.min(pos1.getX(), pos2.getX());
        minY = Math.min(pos1.getY(), pos2.getY());
        minZ = Math.min(pos1.getZ(), pos2.getZ());
        maxX = Math.max(pos1.getX(), pos2.getX());
        maxY = Math.max(pos1.getY(), pos2.getY());
        maxZ = Math.max(pos1.getZ(), pos2.getZ());

        totalLayers = maxY - minY + 1;
        layerStep = layerOrder.get() == LayerOrder.TopDown ? -1 : 1;
        layerY = layerOrder.get() == LayerOrder.TopDown ? maxY : minY;
        layersDone = 0;
        doneBlocks = 0;
        ticksRunning = 0;
        lastQuarter = 0;
        scanTimer = 0;
        delayTimer = 0;
        currentTarget = null;

        cache = scanLayer(layerY);
        layerInitial = cache.size();
        statusText = "Starting";

        info("Mining a %dx%dx%d region (%d blocks of space).",
            maxX - minX + 1, maxY - minY + 1, maxZ - minZ + 1, getRegionVolume());
        refreshPanel();
    }

    @Override
    public void onDeactivate() {
        PathManagers.get().stop();
        cache.clear();
        currentTarget = null;
        if (!statusText.startsWith("Cleared")) statusText = "Idle";
        refreshPanel();
    }

    @EventHandler
    private void onGameLeft(GameLeftEvent event) {
        if (disableOnLeave.get() && isActive()) toggle();
    }

    // ------------------------------------------------------------------- Tick

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.player == null || mc.world == null) return;
        ticksRunning++;

        // ---- safety checks
        if (pauseBelowHealth.get() > 0 && mc.player.getHealth() < pauseBelowHealth.get()) {
            PathManagers.get().stop();
            currentTarget = null;
            setStatus("Paused: low health");
            return;
        }

        if (stopWhenInventoryFull.get()
            && !InvUtils.find(ItemStack::isEmpty, SlotUtils.HOTBAR_START, SlotUtils.MAIN_END).found()) {
            info("Inventory is full, stopping.");
            toggle();
            return;
        }

        if (hotbarSlot.get() > 0) InvUtils.swap(hotbarSlot.get() - 1, false);

        if (stopOnLowDurability.get()) {
            ItemStack held = mc.player.getMainHandStack();
            if (held.isDamageable() && held.getMaxDamage() - held.getDamage() <= minDurability.get()) {
                info("Tool durability is low, stopping.");
                toggle();
                return;
            }
        }

        // ---- layer handling
        if (--scanTimer <= 0 || cache.isEmpty()) {
            cache = scanLayer(layerY);
            layerInitial = Math.max(layerInitial, cache.size());
            scanTimer = rescanInterval.get();
        }

        while (cache.isEmpty()) {
            doneBlocks += layerInitial;
            layersDone++;
            layerY += layerStep;
            if (layerY < minY || layerY > maxY) {
                finish();
                return;
            }
            cache = scanLayer(layerY);
            layerInitial = cache.size();
            scanTimer = rescanInterval.get();
        }

        reportProgress();

        // ---- pick a target
        BlockPos best = pickTarget();
        if (best == null) {
            scanTimer = 0; // everything cached is gone, rescan next tick
            return;
        }
        currentTarget = best;

        Vec3d eye = mc.player.getEyePos();
        double dist = eye.squaredDistanceTo(Vec3d.ofCenter(best));

        if (dist <= range.get() * range.get()) {
            if (PathManagers.get().isPathing()) PathManagers.get().stop();

            if (delayTimer > 0) {
                delayTimer--;
                setStatus("Waiting");
                return;
            }
            if (mine(best)) delayTimer = mineDelay.get();
        } else if (pathing.get()) {
            if (!PathManagers.get().isPathing()) PathManagers.get().moveTo(best.up(), false);
            setStatus("Walking to blocks");
        } else {
            setStatus("Out of range (walking is off)");
        }
    }

    private BlockPos pickTarget() {
        BlockPos best = null;

        if (targetMode.get() == TargetMode.Closest) {
            Vec3d eye = mc.player.getEyePos();
            double bestDist = Double.MAX_VALUE;
            for (BlockPos p : cache) {
                if (!isMineable(p)) continue;
                double d = eye.squaredDistanceTo(Vec3d.ofCenter(p));
                if (d < bestDist) {
                    bestDist = d;
                    best = p;
                }
            }
        } else {
            // Sweep: rows along X, alternating direction each row.
            int width = maxX - minX + 1;
            long bestKey = Long.MAX_VALUE;
            for (BlockPos p : cache) {
                if (!isMineable(p)) continue;
                int row = p.getZ() - minZ;
                int col = (row % 2 == 0) ? p.getX() - minX : maxX - p.getX();
                long key = (long) row * width + col;
                if (key < bestKey) {
                    bestKey = key;
                    best = p;
                }
            }
        }

        return best;
    }

    private void reportProgress() {
        if (!progressMessages.get()) return;
        int quarter = (int) (getProgress() * 4);
        if (quarter > lastQuarter && quarter < 4) {
            lastQuarter = quarter;
            info("%d%% done.", quarter * 25);
        }
    }

    private void setStatus(String text) {
        if (!text.equals(statusText)) statusText = text;
        refreshPanel();
    }

    // ----------------------------------------------------------------- Mining

    /** Returns true if a mining action was actually sent. */
    private boolean mine(BlockPos pos) {
        if (!rotate.get()) {
            setStatus("Mining");
            return BlockUtils.breakBlock(pos, true);
        }

        float targetYaw = (float) Rotations.getYaw(pos);
        float targetPitch = (float) Rotations.getPitch(pos);

        if (smoothRotation.get()) {
            float yaw = mc.player.getYaw();
            float pitch = mc.player.getPitch();
            float dYaw = MathHelper.wrapDegrees(targetYaw - yaw);
            float dPitch = targetPitch - pitch;
            float max = rotationSpeed.get().floatValue();

            mc.player.setYaw(yaw + MathHelper.clamp(dYaw, -max, max));
            mc.player.setPitch(MathHelper.clamp(pitch + MathHelper.clamp(dPitch, -max, max), -90f, 90f));

            // Keep turning until we are roughly on target, then start mining.
            if (Math.abs(dYaw) > 8 || Math.abs(dPitch) > 8) {
                setStatus("Turning");
                return false;
            }
        }

        setStatus("Mining");
        Rotations.rotate(targetYaw, targetPitch, () -> BlockUtils.breakBlock(pos, true));
        return true;
    }

    private List<BlockPos> scanLayer(int y) {
        List<BlockPos> list = new ArrayList<>();
        BlockPos.Mutable p = new BlockPos.Mutable();
        for (int x = minX; x <= maxX; x++) {
            for (int z = minZ; z <= maxZ; z++) {
                p.set(x, y, z);
                if (isMineable(p)) list.add(p.toImmutable());
            }
        }
        return list;
    }

    private boolean isMineable(BlockPos pos) {
        BlockState state = mc.world.getBlockState(pos);
        if (state.isAir()) return false;
        if (state.getBlock() instanceof FluidBlock) return false;
        if (ignoredBlocks.get().contains(state.getBlock())) return false;
        return state.getHardness(mc.world, pos) >= 0; // skips bedrock and other unbreakables
    }

    private void finish() {
        statusText = "Cleared";
        info("Region cleared in %s.", formatTime(getElapsedSeconds()));
        if (autoDisable.get()) toggle();
        else refreshPanel();
    }

    public static String formatTime(long seconds) {
        if (seconds < 0) return "--";
        long h = seconds / 3600;
        long m = (seconds % 3600) / 60;
        long s = seconds % 60;
        if (h > 0) return h + "h " + m + "m";
        if (m > 0) return m + "m " + s + "s";
        return s + "s";
    }

    // ----------------------------------------------------------------- Render

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (renderRegion.get()) {
            if (hasRegion()) {
                int x1 = Math.min(pos1.getX(), pos2.getX());
                int y1 = Math.min(pos1.getY(), pos2.getY());
                int z1 = Math.min(pos1.getZ(), pos2.getZ());
                int x2 = Math.max(pos1.getX(), pos2.getX()) + 1;
                int y2 = Math.max(pos1.getY(), pos2.getY()) + 1;
                int z2 = Math.max(pos1.getZ(), pos2.getZ()) + 1;
                event.renderer.box(x1, y1, z1, x2, y2, z2, sideColor.get(), lineColor.get(), shapeMode.get(), 0);
            } else {
                if (pos1 != null) event.renderer.box(pos1, sideColor.get(), lineColor.get(), shapeMode.get(), 0);
                if (pos2 != null) event.renderer.box(pos2, sideColor.get(), lineColor.get(), shapeMode.get(), 0);
            }
        }

        if (!isActive() || !hasRegion()) return;

        if (renderLayer.get()) {
            event.renderer.box(minX, layerY, minZ, maxX + 1, layerY + 1, maxZ + 1,
                layerSideColor.get(), layerLineColor.get(), shapeMode.get(), 0);
        }

        if (renderTarget.get() && currentTarget != null) {
            event.renderer.box(currentTarget, targetSideColor.get(), targetLineColor.get(), shapeMode.get(), 0);
        }
    }
}
