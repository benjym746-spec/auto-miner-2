package com.example.addon;

import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.WindowScreen;
import meteordevelopment.meteorclient.gui.widgets.WLabel;
import meteordevelopment.meteorclient.gui.widgets.containers.WHorizontalList;
import meteordevelopment.meteorclient.gui.widgets.containers.WSection;
import meteordevelopment.meteorclient.gui.widgets.input.WIntEdit;
import meteordevelopment.meteorclient.gui.widgets.pressable.WButton;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;

import static meteordevelopment.meteorclient.MeteorClient.mc;

/**
 * The Auto Miner control panel: corners, start/stop, live progress and all settings.
 * Open it with ".miner gui" or the "Open Miner Panel" button on the module.
 */
public class MinerScreen extends WindowScreen {
    private static final int LIMIT = 30_000_000;

    /** The panel that is currently open, so the module can refresh it. */
    public static MinerScreen current;

    private final AutoMiner miner;

    private WLabel statusLabel, progressLabel, clearedLabel, timeLabel, volumeLabel;
    private WButton startStop;

    public MinerScreen(GuiTheme theme, AutoMiner miner) {
        super(theme, "Auto Miner");
        this.miner = miner;
    }

    @Override
    public void initWidgets() {
        current = this;

        // ---- Status
        WSection status = add(theme.section("Status", true)).expandX().widget();
        statusLabel = status.add(theme.label("")).expandX().widget();
        progressLabel = status.add(theme.label("")).expandX().widget();
        clearedLabel = status.add(theme.label("")).expandX().widget();
        timeLabel = status.add(theme.label("")).expandX().widget();
        volumeLabel = status.add(theme.label("")).expandX().widget();

        // ---- Controls
        WHorizontalList controls = add(theme.horizontalList()).expandX().widget();
        startStop = controls.add(theme.button("Start")).expandX().widget();
        startStop.action = () -> {
            if (miner.isActive()) {
                miner.toggle();
            } else if (miner.hasRegion()) {
                miner.toggle();
            } else {
                statusLabel.set("Status: set both corners first");
                return;
            }
            update();
        };

        WButton clear = controls.add(theme.button("Clear region")).widget();
        clear.action = () -> {
            miner.clearRegion();
            reload();
        };

        // ---- Corners
        WSection region = add(theme.section("Region", true)).expandX().widget();
        cornerRow(region, 1);
        cornerRow(region, 2);

        // ---- Settings
        WSection settingsSection = add(theme.section("Settings", true)).expandX().widget();
        settingsSection.add(theme.settings(miner.settings)).expandX();

        update();
    }

    private void cornerRow(WSection parent, int which) {
        BlockPos pos = which == 1 ? miner.pos1 : miner.pos2;

        parent.add(theme.label("Corner " + which + ":"));

        WHorizontalList coords = parent.add(theme.horizontalList()).expandX().widget();
        WIntEdit x = coords.add(theme.intEdit(pos == null ? 0 : pos.getX(), -LIMIT, LIMIT, true)).expandX().widget();
        WIntEdit y = coords.add(theme.intEdit(pos == null ? 0 : pos.getY(), -2048, 2048, true)).expandX().widget();
        WIntEdit z = coords.add(theme.intEdit(pos == null ? 0 : pos.getZ(), -LIMIT, LIMIT, true)).expandX().widget();

        Runnable apply = () -> {
            miner.setCorner(which, new BlockPos(x.get(), y.get(), z.get()));
            update();
        };
        x.action = apply;
        y.action = apply;
        z.action = apply;

        WHorizontalList buttons = parent.add(theme.horizontalList()).expandX().widget();

        WButton here = buttons.add(theme.button("My position")).expandX().widget();
        here.action = () -> {
            if (mc.player == null) return;
            miner.setCorner(which, mc.player.getBlockPos());
            reload();
        };

        WButton looking = buttons.add(theme.button("Block I'm looking at")).expandX().widget();
        looking.action = () -> {
            if (mc.crosshairTarget instanceof BlockHitResult hit && hit.getType() == HitResult.Type.BLOCK) {
                miner.setCorner(which, hit.getBlockPos());
                reload();
            } else {
                statusLabel.set("Status: you are not looking at a block");
            }
        };
    }

    /** Called by the module (and the buttons) to refresh the live numbers. */
    public void update() {
        if (statusLabel == null) return;

        statusLabel.set("Status: " + (miner.isActive() ? miner.getStatusText() : idleText()));
        progressLabel.set(String.format("Progress: %.0f%%", miner.getProgress() * 100));
        clearedLabel.set("Cleared: " + miner.getBlocksCleared() + " blocks");
        timeLabel.set("Time: " + AutoMiner.formatTime(miner.getElapsedSeconds())
            + "   Left: " + (miner.isActive() ? AutoMiner.formatTime(miner.getEtaSeconds()) : "--"));
        volumeLabel.set("Region size: " + miner.getRegionVolume() + " blocks");

        startStop.set(miner.isActive() ? "Stop" : "Start");
    }

    private String idleText() {
        String text = miner.getStatusText();
        if (text.equals("Cleared")) return "Cleared";
        return miner.hasRegion() ? "Ready" : "Set both corners to begin";
    }

    @Override
    protected void onClosed() {
        if (current == this) current = null;
        super.onClosed();
    }
}
