package com.example.addon;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import meteordevelopment.meteorclient.commands.Command;
import meteordevelopment.meteorclient.gui.GuiThemes;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.utils.Utils;
import net.minecraft.command.CommandSource;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;

import static meteordevelopment.meteorclient.MeteorClient.mc;

/**
 * .miner gui            open the control panel
 * .miner pos1 [x y z]   set corner 1 (looked-at block, or your feet)
 * .miner pos2 [x y z]   set corner 2
 * .miner start | stop   run / stop the miner
 * .miner clear          forget both corners
 * .miner info           show the current region
 */
public class MinerCommand extends Command {
    public MinerCommand() {
        super("miner", "Set the Auto Miner region and start or stop it.");
    }

    @Override
    public void build(LiteralArgumentBuilder<CommandSource> builder) {
        builder.then(literal("gui").executes(ctx -> {
            Utils.screenToOpen = new MinerScreen(GuiThemes.get(), miner());
            return SINGLE_SUCCESS;
        }));

        builder.then(cornerCommand("pos1", 1));
        builder.then(cornerCommand("pos2", 2));

        builder.then(literal("start").executes(ctx -> {
            AutoMiner miner = miner();
            if (!miner.hasRegion()) {
                error("Set both corners first (.miner pos1 / .miner pos2).");
            } else if (!miner.isActive()) {
                miner.toggle();
            } else {
                info("Already running.");
            }
            return SINGLE_SUCCESS;
        }));

        builder.then(literal("stop").executes(ctx -> {
            AutoMiner miner = miner();
            if (miner.isActive()) miner.toggle();
            info("Stopped.");
            return SINGLE_SUCCESS;
        }));

        builder.then(literal("clear").executes(ctx -> {
            miner().clearRegion();
            info("Region cleared.");
            return SINGLE_SUCCESS;
        }));

        builder.then(literal("info").executes(ctx -> {
            AutoMiner miner = miner();
            info("pos1: %s", miner.pos1 == null ? "not set" : miner.pos1.toShortString());
            info("pos2: %s", miner.pos2 == null ? "not set" : miner.pos2.toShortString());
            info("size: %d blocks", miner.getRegionVolume());
            info("running: %s (%s)", miner.isActive(), miner.getStatusText());
            return SINGLE_SUCCESS;
        }));
    }

    private LiteralArgumentBuilder<CommandSource> cornerCommand(String name, int which) {
        return literal(name)
            .executes(ctx -> {
                setCorner(which, targetedOrFeet());
                return SINGLE_SUCCESS;
            })
            .then(argument("x", IntegerArgumentType.integer())
                .then(argument("y", IntegerArgumentType.integer())
                    .then(argument("z", IntegerArgumentType.integer())
                        .executes(ctx -> {
                            setCorner(which, new BlockPos(
                                IntegerArgumentType.getInteger(ctx, "x"),
                                IntegerArgumentType.getInteger(ctx, "y"),
                                IntegerArgumentType.getInteger(ctx, "z")));
                            return SINGLE_SUCCESS;
                        }))));
    }

    private AutoMiner miner() {
        return Modules.get().get(AutoMiner.class);
    }

    private BlockPos targetedOrFeet() {
        if (mc.crosshairTarget instanceof BlockHitResult hit && hit.getType() == HitResult.Type.BLOCK) {
            return hit.getBlockPos();
        }
        return mc.player.getBlockPos();
    }

    private void setCorner(int which, BlockPos pos) {
        miner().setCorner(which, pos);
        info("Corner %d set to %s.", which, pos.toShortString());
    }
}
