# Auto Miner (Meteor Client addon)

Minecraft 1.21.11 + Meteor Client 1.21.11.

Open the panel with `.miner gui` (or click the module and press "Open Miner Panel"):
set both corners, press Start, watch the progress. All settings are in the panel.

Commands: `.miner gui | pos1 [x y z] | pos2 [x y z] | start | stop | clear | info`

Every push builds the jar via GitHub Actions; get it from Releases.
